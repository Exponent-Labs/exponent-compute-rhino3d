#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name='compute-rhino3d',
      version='0.0.1',
      description='Patched version',
      packages=["compute_rhino3d"],
      license='',
    )